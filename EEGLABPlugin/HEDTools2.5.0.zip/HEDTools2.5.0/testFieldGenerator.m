% javaaddpath(['/Users/dtyoung/Documents/HED/hed-matlab/matlab/jars/' 'ctagger.jar']);
% loader = javaObject('edu.utsa.tagger.TaggerLoader', ...
%             p.xml, p.tValues, p.flags, p.eTitle, p.initialDepth)
loader = javaObject('edu.utsa.tagger.FieldGeneratorLoader', '{"newFieldName": "trial_type", "eventFields": {"type": ["square", "rt"], "position": ["1", "2"]}}');
